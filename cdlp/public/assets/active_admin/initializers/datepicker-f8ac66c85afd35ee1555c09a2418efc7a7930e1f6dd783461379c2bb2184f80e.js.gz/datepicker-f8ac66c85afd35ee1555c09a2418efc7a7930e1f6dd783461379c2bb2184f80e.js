(function() {
  $(document).on('ready page:load turbolinks:load', function() {
    return $(document).on('focus', 'input.datepicker:not(.hasDatepicker)', function() {
      var defaults, input, options;
      input = $(this);
      if (input[0].type === 'date') {
        return;
      }
      defaults = {
        dateFormat: 'yy-mm-dd'
      };
      options = input.data('datepicker-options');
      return input.datepicker($.extend(defaults, options));
    });
  });

}).call(this);
